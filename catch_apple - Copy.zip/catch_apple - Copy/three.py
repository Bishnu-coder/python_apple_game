#import
import pygame
import sys
import random
#loads modules
screen=pygame.display.set_mode((800,600))
pygame.font.init()
pygame.display.flip()
pygame.display.set_caption("collect the apples")
clock=pygame.time.Clock()
player=pygame.image.load('photo/bask.png').convert_alpha()
pygame.mixer.init()
pygame.mixer.music.load('music/score.mp3')
pygame.mixer.music.set_volume(0.5)
appple=pygame.image.load('photo/apple.png').convert_alpha()
bomb=pygame.image.load('photo/bomb.png')
font = pygame.font.Font("font/AGENCYR.TTF", 32)
heart_photo=pygame.image.load("photo/heart.png").convert_alpha()
# game logics ints
fps=30
player_x=350
player_y=500
appple_x=random.randrange(0,650)
apple_y=0
bomb_x=random.randrange(0,650)
bomb_y=0
heart_x=random.randrange(0,650)
heart_y=0
vel_apple=2.5
vel_plyer=8
score=35
blue=(0,0,255)
heart=3
f= open("hs.txt","r")
highscore=f.read()
#bool logics
start_level=False
bomb_blast=False
game_over=False
game=True
running=True
#functions
def txt_screen(text,color,x,y):
    screen_txt=font.render(text,True,color)
    screen.blit(screen_txt,[x,y])
def get_RECT(x,y,w,h):
    pygame.draw.rect(screen,blue,pygame.Rect(x,y,w,h),2)
#game loop
while True:
    mouse=pygame.mouse.get_pos()
    #for loop
    for event in pygame.event.get():
        keys=pygame.key.get_pressed()
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()
    screen.fill((255,255,255))
    # if statements for game
    if start_level==False:
        game==False
        txt_screen("welcome to level 3",(0,0,0),200,200)
        txt_screen("press space to play",(0,0,0),250,250)
    if keys[pygame.K_SPACE]:
        start_level=True
        game==True
    if game==True and keys[pygame.K_LEFT]:
        player_x-=vel_plyer
        start_level=True
    if game==True and keys[pygame.K_RIGHT]:
        player_x+=vel_plyer
        start_level=True
    if game==True and apple_y>=600:
        apple_y=0
        appple_x=random.randrange(0,650)
        heart-=1
    if game==True and abs(player_x-appple_x)<=100 and apple_y>=player_y:
        appple_x=random.randrange(0,650)
        apple_y=0
        vel_apple+=1
        vel_plyer+=1
        score+=1
        pygame.mixer.music.play(0)
    if bomb_y>=600:
        bomb_y=0
        bomb_x=random.randrange(0,650)
    if heart_y>=600:
        heart_y=0
        heart_x=random.randrange(0,650)
    if game==True and abs(player_x-bomb_x)<=80 and bomb_y>=player_y:
        bomb_x=random.randrange(0,650)
        bomb_y=0
        heart-=1
        pygame.mixer.Channel(1).play(pygame.mixer.Sound('music/bomb.mp3'))
    if game==True and abs(player_x-heart_x)<=80 and heart_y>=player_y:
        heart_y=0
        heart_x=random.randrange(0,650)
        heart+=1
    if heart==0:
        txt_screen('game over',blue,350,200)
        game=False 
        game_over=True
    if game_over==True and game==False:
        txt_screen('press to play again',blue,300,300)
        get_RECT(300,300,300,50)
    if mouse[0]>=300 and mouse[0]<=600 and mouse[1]>=300 and mouse[1]<=350:
        if event.type==pygame.MOUSEBUTTONDOWN:
            game=True
            heart=3
            score=0
            vel_apple=2.5
            import one
            sys.exit()
    if player_x>=660:
        player_x=650
    if player_x<=0:
        player_x=5
    if score>int(highscore):
        highscore=score
    if heart>6:
        heart=0
    if game==True:
        f=open("hs.txt","w")
        f.write(str(highscore))
        f.close()
    #drawing
    screen.blit(bomb,(bomb_x,bomb_y))
    screen.blit(appple,(appple_x,apple_y))
    screen.blit(player,(player_x,player_y))
    screen.blit(heart_photo,(heart_x,heart_y))
    apple_y+=vel_apple
    bomb_y+=vel_apple
    heart_y+=vel_apple
    txt_screen('score='+str(score),blue,10,10)
    txt_screen('heart='+str(heart),blue,10,50)  
    txt_screen('highscore='+str(highscore),blue,570,0)
    #updating
    pygame.display.flip()
    pygame.time.delay(10)
    pygame.display.update()
    clock.tick(fps)
#end
