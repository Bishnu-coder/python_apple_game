import sys
import pygame
import os
#loads
pygame.init()
screen=pygame.display.set_mode((800,600))
pygame.display.set_caption("catch apple")
font = pygame.font.Font("font/AGENCYR.TTF", 32)
#bools
running=True
#tuples
blue=(0,0,255)
red=(255,0,0)
#funcs
def get_RECT(x,y,w,h):
    global screen
    rec=pygame.Rect(x,y,w,h)
    pygame.draw.rect(screen,blue,rec)
def txt_screen(text,color,x,y):
    screen_txt=font.render(text,True,color)
    screen.blit(screen_txt,[x,y])
#while loop

while running:
    mouse=pygame.mouse.get_pos()
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running=False
    screen.fill((255,255,255))
    lv1=get_RECT(0,10,180,100)
    txt_screen("level-1 score:0 ",red,5,20)
    lv2=get_RECT(0,150,180,100)
    txt_screen("level-2 score:10",red,5,150)
    lv3=get_RECT(0,290,180,100)
    txt_screen("level 3 score:35",red,5,290)
    if mouse[0]>=0 and mouse[0]<=180 and mouse[1]>=10 and mouse[1]<=100:
        if event.type==pygame.MOUSEBUTTONDOWN:
            lxpath="one.exe"
            os.startfile(lxpath)
            sys.exit()
    if mouse[0]>=0 and mouse[0]<=180 and mouse[1]>=150 and mouse[1]<=250:
        if event.type==pygame.MOUSEBUTTONDOWN:
            lxpath="lv2.exe"
            os.startfile(lxpath)
            sys.exit()
    if mouse[0]>=0 and mouse[0]<=180 and mouse[1]>=290 and mouse[1]<=400:
        if event.type==pygame.MOUSEBUTTONDOWN:
            lxpath="three.exe"
            os.startfile(lxpath)
            sys.exit()

    pygame.display.update()
