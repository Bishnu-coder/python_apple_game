#import
import pygame
import sys
import random
#logics
screen=pygame.display.set_mode((800,600))
pygame.font.init()
pygame.display.flip()
pygame.display.set_caption("collect the apples")
running=True
fps=30
clock=pygame.time.Clock()
player=pygame.image.load('photo/bask.png')
pygame.mixer.init()
pygame.mixer.music.load('music/score.mp3')
pygame.mixer.music.set_volume(0.5)
player_x=350
player_y=500
appple=pygame.image.load('photo/apple.png')
appple_x=random.randrange(0,650)
apple_y=0
vel_apple=2.5
vel_plyer=8
score=0
blue=(0,0,255)
heart=3
game=True
run=True
f= open("hs.txt","r")
highscore=f.read()
font = pygame.font.Font("font/AGENCYR.TTF", 32)
def txt_screen(text,color,x,y):
    screen_txt=font.render(text,True,color)
    screen.blit(screen_txt,[x,y])
def get_RECT(x,y,w,h):
    pygame.draw.rect(screen,blue,pygame.Rect(x,y,w,h),2)
while True:
    mouse=pygame.mouse.get_pos()
    for event in pygame.event.get():
        keys=pygame.key.get_pressed()
        if event.type==pygame.QUIT:
            pygame.quit()
            sys.exit()
    screen.fill((255,255,255))
    if game==True and keys[pygame.K_LEFT]:
        player_x-=vel_plyer
    if game==True and keys[pygame.K_RIGHT]:
        player_x+=vel_plyer
    if game==True and apple_y>=600:
        apple_y=0
        appple_x=random.randrange(0,650)
        heart-=1
    if game==True and abs(player_x-appple_x)<=100 and apple_y>=player_y:
        appple_x=random.randrange(0,650)
        apple_y=0
        vel_apple+=1
        vel_plyer+=1
        score+=1
        pygame.mixer.music.play()
    screen.blit(player,(player_x,player_y))
    apple_y+=vel_apple
    txt_screen('score='+str(score),blue,10,10)
    txt_screen('heart='+str(heart),blue,10,50)  
    if heart==0:
        txt_screen('game over',blue,350,200)
        game=False 
    screen.blit(appple,(appple_x,apple_y))
    if game==False:
        txt_screen('press to play again',blue,300,300)
        get_RECT(300,300,300,50)
    if mouse[0]>=300 and mouse[0]<=600 and mouse[1]>=300 and mouse[1]<=350:
        if event.type==pygame.MOUSEBUTTONDOWN:
            game=True
            heart=3
            score=0
    if player_x>=660:
        player_x=650
    if player_x<=0:
        player_x=5
    if score>int(highscore):
        highscore=score
    if game==True:
        f=open("hs.txt","w")
        f.write(str(highscore))
        f.close()
    if score>=10:
        import lv2
       # pygame.quit()
        sys.exit()
    txt_screen('highscore='+str(highscore),blue,570,0)
    pygame.display.flip()
    pygame.time.delay(10)
    pygame.display.update()
    clock.tick(fps)

#end
